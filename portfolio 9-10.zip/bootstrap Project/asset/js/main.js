// slick slider testimonial

$('.autoplay').slick({
  slidesToShow:1,
  slideToScroll:1,
  autoplay:true,
  autoplaySpeed:1000,
 

});